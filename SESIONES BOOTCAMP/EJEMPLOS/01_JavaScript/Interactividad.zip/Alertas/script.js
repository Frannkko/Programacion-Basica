const eliminarBtn = document.getElementById('eliminarBtn');

eliminarBtn.addEventListener('click', function() {
    const confirmacion = confirm('¿Estás seguro de que deseas eliminar tu cuenta? Esta acción es irreversible.');
    if (confirmacion) {
        // Aquí iría el código para eliminar la cuenta
        alert('Tu cuenta ha sido eliminada.');
    } else {
        alert('Acción cancelada.');
    }
});
