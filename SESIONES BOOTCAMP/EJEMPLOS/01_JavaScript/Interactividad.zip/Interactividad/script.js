// Obtener elementos del DOM
const form = document.getElementById('registroForm');
const nombre = document.getElementById('nombre');
const email = document.getElementById('email');
const password = document.getElementById('password');

const errorNombre = document.getElementById('errorNombre');
const errorEmail = document.getElementById('errorEmail');
const errorPassword = document.getElementById('errorPassword');

// Funciones de validación
function validarNombre() {
    if (nombre.value.trim() === '') {
        errorNombre.textContent = 'El nombre es obligatorio.';
    } else {
        errorNombre.textContent = '';
    }
}

function validarEmail() {
    const regexEmail = /\S+@\S+\.\S+/;
    if (!regexEmail.test(email.value)) {
        errorEmail.textContent = 'Ingresa un correo electrónico válido.';
    } else {
        errorEmail.textContent = '';
    }
}

function validarPassword() {
    if (password.value.length < 6) {
        errorPassword.textContent = 'La contraseña debe tener al menos 6 caracteres.';
    } else {
        errorPassword.textContent = '';
    }
}

// Eventos
nombre.addEventListener('input', validarNombre);
email.addEventListener('input', validarEmail);
password.addEventListener('input', validarPassword);

form.addEventListener('submit', function(event) {
    validarNombre();
    validarEmail();
    validarPassword();

    if (errorNombre.textContent || errorEmail.textContent || errorPassword.textContent) {
        event.preventDefault();
    } else {
        alert('Formulario enviado con éxito.');
    }
});
